const { parentPort, workerData } = require('worker_threads');
// process.UV_THREADSIZE_POOL = 2
parentPort.on('message', (message) => {
    console.log(message);
    const { collection } = workerData
    console.log({ collection })

    // collection read
    parentPort.postMessage([collection])
})