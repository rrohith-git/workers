/*
device management
user management
5 tables
1 one => pull it one db
2 one => push into other db
*/
const express = require('express');
const { Worker } = require('worker_threads');
const app = express();
const PORT = 3000;
app.use(express.json());


function createWorkers(collectionName) {
    return new Promise((resolve,reject) => {
        const workerThread = new Worker('./Workers/index.js', { workerData: { collection: collectionName } })
        workerThread.on('message', (data) => {
            console.log(data)
            resolve(data)
        });
        workerThread.on('error', (err) => {
            console.log({ err })
            reject(err)
        })
        workerThread.postMessage('start');
    });
}

app.get('/export', function () {
    const collections = ['users','device','tenants','alerts','masterData']
   const returnedCollectionPromise = collections.map(collection => createWorkers(collection))
   Promise.all(returnedCollectionPromise).then((response) => {
    console.log(response)
   })   
});

app.post('/import', function () {

});

app.listen(PORT, () => {
    console.log(`Application started on port ${PORT}`);
});